/** 
 * Functions
 * 1. Anonymous Function & Function Expression 🐱‍🚀💖
 */



let anonymousFunction = function greetMessage (){
    console.log("Hello from GFG"); // hello from gfg
    console.log(typeof greetMessage) // function
}

console.log(typeof anonymousFunction); // function

anonymousFunction();


