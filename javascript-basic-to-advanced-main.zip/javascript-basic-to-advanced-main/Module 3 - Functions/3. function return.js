/**
 * Functions 🔥🔥🔥
 * return 🚀🚀
 */

function calculateSum(x, y){
    return x + y;
}

// console.log(calculateSum(12, 15));

const result = calculateSum(13, 21);
console.log(result);

// const output = calculateSum(99, 101);
// console.log(output);