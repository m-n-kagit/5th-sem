/**
 * pop, slice, splice 🌟🌟
 */

let courses = ["html", "css", "js", "jqyery", "vue.js", "angular"];

courses.splice(3, 0, "reactjs");

console.log(courses);













// let courses = ["html", "css", "js", "reactjs", "jquery"];

// let value = courses.slice(0, 4);
// console.log(courses)
// console.log(value);

// let userName = "PRAKASH";

// let firstUpperCaseChar = userName[0].toUpperCase();
// let capitalizeName = firstUpperCaseChar + userName.slice(1).toLowerCase();

// console.log(capitalizeName);












// console.log("Courses -", courses);
// let removedItem = courses.pop();
// console.log("RI -", removedItem);
// console.log("Updated Courses -", courses);

// removedItem = courses.pop();
// console.log("RI Again -", removedItem);
// console.log("Updated Courses Again -", courses);