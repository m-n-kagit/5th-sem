/**
 * Destructuring Array🚀🚀
 */

// const arr = [["html", "css", "js"], 1, 2, 3, 4, 5, 6];

// const [courses,a, b,  ...rest] = arr;

// console.log(rest);
// console.log(courses);

/** Swap Numbers */

let a = 5;
let b = 10;

[a, b] = [b, a];

console.log("A -", a);
console.log("B -", b);
