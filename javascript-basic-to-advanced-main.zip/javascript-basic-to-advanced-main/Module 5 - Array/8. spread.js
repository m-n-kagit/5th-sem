/**
 * spread
 * ..arr🔥🚀
 */

const arr1 = [1, 2, 3, 4, 5];
const arr2 = [8, 9];

const arr3 = [...arr1, 6, 7, ...arr2, 10, 11];
console.log(arr3);

console.log(arr1);