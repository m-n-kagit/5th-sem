/**
 * Nullish Coalescing ?? 🔥🔥
 * || vs ?? 🚀🚀
 */

let firstName = 0;
console.log(firstName ?? "HiddenGeeks");

// const a = 0;

// console.log(a ?? 1);

// let a = 12
// let b;

// console.log(a + (b ?? 0));