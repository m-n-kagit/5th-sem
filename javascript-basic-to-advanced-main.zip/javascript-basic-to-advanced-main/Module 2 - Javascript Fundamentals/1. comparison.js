
/** Comparison Operators */


// console.log(50 > 30);

// console.log(30 >= 30);

// console.log(50 == 40);

// String

// console.log("apple" > "banana");

// console.log("glowing" > "glow");

// console.log("2" > 1);
// console.log("01" == 1);

/** Strict Equality */

// console.log("01" === 1);

console.log(null == undefined);
// console.log(null === undefined);

console.log(null > 0); // null becomes 0

console.log(null < 1);

console.log(null >= 0);

// console.log(null == 0); // here null is null













/** 
 * 3 <= 5 --> true
 * "mango" > "banana" --> true
 * "2" > "3" --> false
 * undefined == null --> true
 * null === undefined --> false
 * null < 1 --> true
*/