/**
 * for loop
 */

const userName = "Prakash Narsingrao Sakari Padma";

const stringLength = userName.length;

for (let i=0; i<stringLength; i++){
    console.log(userName[i])
}