# form-validation
Built with Javascript this app allows form validation with regex
