/**
 * map, filter, reduce
 */



