/**
 * Lesson - 2
 * Why Variables 🚀
 * What is a Variable 🔥
 * Different ways to create variables ⭐
 */

// var message;

// message = "Hello GeeksforGeeks!";

// message = "My name is Prakash Sakari!";

// console.log(message);

let text; //Creating Variable or Declaring a variable

text = "JavaScript is the best!!!!"; // Assigning a value to a variable

// console.log(text);

// let myname = "Prakash Sakari!!"

// console.log(myname);

const number = 1;

console.log(number);
