
const x = "mango";
const y = "apple";

console.log(x + y);

console.log(x - y);

console.log(x * y);

console.log(x / y);

console.log(x % y);

console.log(x ** 2);

console.log(y ** 3);