/**
 * Lesson 3
 * var v/s let v/s const 
 */

// var message = "Hello";
// var message = "Hii";
// var message = "Bye";
// console.log(message);

// let message = "Hello";
// message = "Hiii";
// console.log(message);

const message = "hello";
console.log(message);

