/**
 * First Program - Show Hello Geeks on Console
 * Understand what is console.
*/

console.log('Hello Geeks!!');
console.log("My name is Prakash Sakari!")

console.log(7 + 3);