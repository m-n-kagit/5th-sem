/**
 * Lesson 4
 * Variable Naming Convention
 */
 let userName = "Prakash";
let userAge;
let userHomeAddress;

let age;

let Age;

// let _;

// let $ = "Hello";
// console.log($)

// let number1;

// let number_2;


console.log(userName);

