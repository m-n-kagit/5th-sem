/** 
 * Type Conversion 🌟🌟
 * to String..
 * to Number..
 * to Boolean..
*/


const a = "prakash";
const b = 0;


console.log(Boolean(b));


// const c = String(a);
// const d = String(b);

// console.log(typeof a);
// console.log(typeof b);
// console.log(typeof c);
// console.log(typeof d);