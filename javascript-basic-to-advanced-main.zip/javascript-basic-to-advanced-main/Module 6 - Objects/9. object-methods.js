/**
 * Object Methods
 */

const obj = {
  x: 1,
  y: 2,
  z: 17,
};

const values = Object.values(obj);
console.log(values);
