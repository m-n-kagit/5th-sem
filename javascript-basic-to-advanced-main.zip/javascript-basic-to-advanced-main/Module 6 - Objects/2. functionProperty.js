/**
 * Function as Object Property🔥🔥
 */

const obj = {
    name: "Prakash Sakari",
    greetMessage: function (){
        console.log("Hello Prakash Welcome to GFG!!!!!");
    },
    bye(){
        console.log("Tata Bye Bye");
    }
}

obj.bye();
