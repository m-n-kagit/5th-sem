/**
 * Objects --> {key: value} 🔥🔥🔥
 */

//Object Literal
const personObj = {
    name: "Prakash", //property
    age: 99,
    job: "Mentor",
    course: ["html", "css", "js", "reactjs"],
    "is Admin": "true"
}; 

// console.log(personObj.age);
// console.log(personObj.name);


console.log(personObj["name"]);
console.log(personObj["job"]);
console.log(personObj["is Admin"]);