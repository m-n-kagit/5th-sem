/**
 * Short Hand ✋✋
 */

function getOjects(name, city){
    return {
        name,
        city
    }
}

const student1 = getOjects("Prakash", "Mumbai");
console.log(student1);

const student2 = getOjects("ashish", "sirsa");
console.log(student2);

// const student = "ashish";
// const course = "redux";

// console.log({student, course})
