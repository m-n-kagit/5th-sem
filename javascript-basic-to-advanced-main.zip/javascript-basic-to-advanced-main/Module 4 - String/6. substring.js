/**
 * sub string 🔥
 */

const userName = "Prakash Narsingrao Sakari";

const subString = userName.substring(0, 10);

console.log(subString + "...");