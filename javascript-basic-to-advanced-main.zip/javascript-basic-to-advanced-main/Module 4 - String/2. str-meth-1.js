/**
 * String Methods 🔥🔥
 * charAt() | charCodeAt()
 */

const displayMessage = "I am a Mentor at GeeksforGeekS";
const index = 29;
const char = displayMessage.charAt(index);

// console.log(char);

// ASCII

const asciiCode = displayMessage.charCodeAt(index);
console.log(`The acsii code of ${char} is ${asciiCode}`)


/**
 * exercise to encode
 * geeks --> iffmu
 */