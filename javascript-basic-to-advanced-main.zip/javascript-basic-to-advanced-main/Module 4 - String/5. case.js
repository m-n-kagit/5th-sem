/**
 * uppercase() and lowercase()
 */

const message = "I am Prakash Sakari and I am 111 years old!!";
console.log(message.toLowerCase());
console.log(message);
console.log(message.toUpperCase());