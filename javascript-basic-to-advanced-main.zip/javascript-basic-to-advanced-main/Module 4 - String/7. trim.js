/**
 * String.trim() 🚀⚡🚀
 */


const text = "              Hola!! I love GFG                                            ";
console.log(text.trim().substring(0, 6) + "......");