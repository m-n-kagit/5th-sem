/**
 * Iterating over Strings
 */

let displayMessage = "I am a Mentor at GeeksforGeeks"

for (let i=0; i<displayMessage.length; i++){
    if(displayMessage[i] === "r"){
        console.log(i);
    }
}












// let count = 0;
// for (let char of displayMessage){
//     if (char === "e"){
//         count++
//     }
// }
// console.log(count);